Here is a collection about console, IO and files. 
